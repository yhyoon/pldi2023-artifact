# Probe

This code is the implementation for the paper [Just-in-Time Learning for Bottom-Up Enumerative Synthesis](https://shraddhabarke.github.io/raw/probe.pdf).
It is released under [CRAPL--the Community Research and Academic Programming License](http://matt.might.net/articles/crapl/).
