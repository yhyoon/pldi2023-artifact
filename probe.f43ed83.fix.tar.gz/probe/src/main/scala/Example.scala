package sygus
case class Example(input: Map[String,Any], output: Any)
